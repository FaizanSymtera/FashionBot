// App.js
import React, { useState, useEffect, useCallback, useRef } from 'react';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import './App.css';
import { FaBars } from 'react-icons/fa';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [hamburgerVisible, setHamburgerVisible] = useState(true);
  const [isConversationStarted, setIsConversationStarted] = useState(false);
  const [messages, setMessages] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [userId] = useState(() => {
    // Generate a unique user ID or get from localStorage
    const storedUserId = localStorage.getItem('fashion_chatbot_user_id');
    if (storedUserId) return storedUserId;
    
    const newUserId = 'user_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('fashion_chatbot_user_id', newUserId);
    return newUserId;
  });
  const [chats, setChats] = useState([]); // All user chats
  const [loading, setLoading] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const abortControllerRef = useRef(null);

  // New state variables for cost information
  const [totalCostUsd, setTotalCostUsd] = useState(0);
  const [totalCostPkr, setTotalCostPkr] = useState(0);
  const [totalInputTokens, setTotalInputTokens] = useState(0);
  const [totalOutputTokens, setTotalOutputTokens] = useState(0);
  const [totalImageDisplays, setTotalImageDisplays] = useState(0);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  const handleScroll = (scrollTop) => {
    setHamburgerVisible(scrollTop <= 10);
  };

  // New function to stop the current bot response
  const handleStopMessage = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setLoading(false);
    }
  };

  useEffect(() => {
    const handleResize = () => {
      const sidebarWidth = window.innerWidth > 768 ? 250 : 0;
      document.documentElement.style.setProperty('--sidebar-width', `${sidebarWidth}px`);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Multi-chat functions
  const fetchUserChats = useCallback(async () => {
    if (!userId) return;
    try {
      const response = await fetch(`/api/chats/${userId}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
      const data = await response.json();
      console.log("✅ Fetched user chats:", data);
      setChats(data.chats || []);
    } catch (error) {
      console.error("Error fetching user chats:", error);
      setChats([]);
    }
  }, [userId]);

  const createNewChat = async () => {
    try {
      setChatLoading(true);
      const response = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          chat_name: 'New Chat'
        }),
      });
      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
      const data = await response.json();
      console.log("✅ Created new chat:", data);
      
      // Add new chat to the list
      setChats(prev => [data.chat, ...prev]);
      setCurrentChatId(data.chat._id);
      setMessages([]);
      setIsConversationStarted(false);
      
      return data; // Return the created chat data
    } catch (error) {
      console.error("Error creating new chat:", error);
      return null;
    } finally {
      setChatLoading(false);
    }
  };

  const switchToChat = async (chatId) => {
    try {
      setChatLoading(true);
      const response = await fetch(`/api/chats/${chatId}/messages?user_id=${userId}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
      const data = await response.json();
      
      // Format messages for frontend
      const formattedMessages = data.messages.map(msg => {
        const imageContent = msg.image ? { src: msg.image.data, mimeType: msg.image.mime_type } : null;
        
        const mapProductsForFrontend = (products) => {
          return products.map(p => ({
            id: p.id,
            src: p.image_urls && p.image_urls.length > 0 ? p.image_urls[0] : '',
            alt: p.name,
            title: p.name,
            price_pkr: p.price_pkr,
            price_usd: p.price_usd,
            on_sale: p.on_sale,
            sale_price_pkr: p.sale_price_pkr,
            sale_price_usd: p.sale_price_usd,
            description: p.description,
            category: p.category,
            gender: p.gender,
            materials: p.materials,
            components: p.components,
            details: p.details,
            sizes_available: p.sizes_available,
            colors_available: p.colors_available,
            in_stock: p.in_stock,
          }));
        };

        const hasProductsToDisplay = (msg.mainProducts && msg.mainProducts.length > 0) ||
                                     (msg.suggestiveProducts && msg.suggestiveProducts.length > 0);

        return {
          text: msg.text,
          sender: msg.role === 'user' ? 'user' : 'bot',
          timestamp: msg.timestamp || new Date().toISOString(),
          image: imageContent,
          type: hasProductsToDisplay ? 'productDisplay' : 'text',
          mainProducts: mapProductsForFrontend(msg.mainProducts || []),
          suggestiveProducts: mapProductsForFrontend(msg.suggestiveProducts || []),
        };
      });

      setMessages(formattedMessages);
      setCurrentChatId(chatId);
      setIsConversationStarted(formattedMessages.length > 0);
      console.log(`✅ Switched to chat ${chatId} with ${formattedMessages.length} messages`);
    } catch (error) {
      console.error("Error switching to chat:", error);
      setMessages([]);
      setCurrentChatId(chatId);
      setIsConversationStarted(false);
    } finally {
      setChatLoading(false);
    }
  };

  const deleteChat = async (chatId) => {
    try {
      const response = await fetch(`/api/chats/${chatId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId }),
      });
      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
      
      // Remove chat from list
      setChats(prev => prev.filter(chat => chat._id !== chatId));
      
      // If deleted chat was current, switch to first available or create new
      if (currentChatId === chatId) {
        const remainingChats = chats.filter(chat => chat._id !== chatId);
        if (remainingChats.length > 0) {
          switchToChat(remainingChats[0]._id);
        } else {
          setCurrentChatId(null);
          setMessages([]);
          setIsConversationStarted(false);
        }
      }
    } catch (error) {
      console.error("Error deleting chat:", error);
    }
  };

  const renameChat = async (chatId, newName) => {
    try {
      const response = await fetch(`/api/chats/${chatId}/rename`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          chat_name: newName
        }),
      });
      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
      
      // Update chat in list
      setChats(prev => prev.map(chat => 
        chat._id === chatId ? { ...chat, chat_name: newName } : chat
      ));
    } catch (error) {
      console.error("Error renaming chat:", error);
    }
  };

  // Legacy function for backward compatibility
  const fetchChatHistory = useCallback(async () => {
    if (!userId) return;
    try {
      const response = await fetch('/api/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId }),
      });
      if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
      const data = await response.json();
      console.log("✅ Fetched chat history and costs:", data);

      const formattedMessages = data.history.map(msg => {
        const imageContent = msg.image ? { src: msg.image.data, mimeType: msg.image.mime_type } : null;

        const mapProductsForFrontend = (products) => {
          return products.map(p => ({
            id: p.id,
            src: p.image_urls && p.image_urls.length > 0 ? p.image_urls[0] : '',
            alt: p.name,
            title: p.name,
            price_pkr: p.price_pkr,
            price_usd: p.price_usd,
            on_sale: p.on_sale,
            sale_price_pkr: p.sale_price_pkr,
            sale_price_usd: p.sale_price_usd,
            description: p.description,
            category: p.category,
            gender: p.gender,
            materials: p.materials,
            components: p.components,
            details: p.details,
            sizes_available: p.sizes_available,
            colors_available: p.colors_available,
            in_stock: p.in_stock,
          }));
        };

        const hasProductsToDisplay = (msg.main_recommended_products && msg.main_recommended_products.length > 0) ||
                                     (msg.suggestive_recommended_products && msg.suggestive_recommended_products.length > 0);

        return {
          text: msg.text,
          sender: msg.role === 'user' ? 'user' : 'bot',
          timestamp: msg.timestamp || new Date().toISOString(),
          image: imageContent,
          type: hasProductsToDisplay ? 'productDisplay' : 'text',
          mainProducts: mapProductsForFrontend(msg.main_recommended_products || []),
          suggestiveProducts: mapProductsForFrontend(msg.suggestive_recommended_products || []),
        };
      });

      setMessages(formattedMessages);
      setIsConversationStarted(formattedMessages.length > 0);

      setTotalCostUsd(data.total_cost_usd || 0);
      setTotalCostPkr(data.total_cost_pkr || 0);
      setTotalInputTokens(data.total_input_tokens || 0);
      setTotalOutputTokens(data.total_output_tokens || 0);
      setTotalImageDisplays(data.total_image_displays || 0);

    } catch (error) {
      console.error("Error fetching chat history:", error);
      setMessages([]);
    }
  }, [userId]);

  useEffect(() => {
    fetchUserChats();
    // If no chats exist, create a default one
    if (chats.length === 0 && !chatLoading) {
      createNewChat();
    }
  }, [userId, fetchUserChats]);

  useEffect(() => {
    // Set current chat to the first one if none is selected
    if (chats.length > 0 && !currentChatId) {
      setCurrentChatId(chats[0]._id);
      switchToChat(chats[0]._id);
    }
  }, [chats, currentChatId]);

  const handleSendMessage = async (messagePayload) => {
    const messageText = messagePayload.text;
    const messageImageBase64 = messagePayload.image; // This will be base64 from ChatInput

    if (!messageText.trim() && !messageImageBase64) return;

    // Create new chat if no current chat exists
    if (!currentChatId) {
      const newChat = await createNewChat();
      if (newChat && newChat.chat && newChat.chat._id) {
        setCurrentChatId(newChat.chat._id);
      }
    }

    const now = new Date().toISOString();
    const userMsg = { text: messageText, sender: 'user', timestamp: now, image: messageImageBase64 ? { src: `data:image/jpeg;base64,${messageImageBase64}` } : null };

    setMessages(prev => [...prev, userMsg]);
    setIsConversationStarted(true);

    // Create new abort controller for this request
    abortControllerRef.current = new AbortController();
    setLoading(true);

    try {
      const requestBody = {
        user_id: userId,
        message: messageText,
        chat_id: currentChatId, // Add current chat ID
      };

      if (messageImageBase64) {
        requestBody.image = messageImageBase64;
        requestBody.image_mime_type = 'image/jpeg';
      }

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`HTTP error: ${response.status} - ${errorData.error || response.statusText}`);
      }

      const data = await response.json();
      console.log("✅ Backend chat response:", data);

      const botResponseText = data.reply || "I'm sorry, I couldn't generate a response.";

      // Function to map product data for frontend ProductCard
      const mapProductsForFrontend = (products) => {
        return products.map(p => ({
            id: p.id,
            src: p.image_urls && p.image_urls.length > 0 ? p.image_urls[0] : '',
            alt: p.name,
            title: p.name,
            price_pkr: p.price_pkr,
            price_usd: p.price_usd,
            on_sale: p.on_sale,
            sale_price_pkr: p.sale_price_pkr,
            sale_price_usd: p.sale_price_usd,
            description: p.description,
            category: p.category,
            gender: p.gender,
            materials: p.materials,
            components: p.components,
            details: p.details,
            sizes_available: p.sizes_available,
            colors_available: p.colors_available,
            in_stock: p.in_stock,
        }));
      };

      const mainRecommendedProducts = data.main_recommended_products || []; // New
      const suggestiveRecommendedProducts = data.suggestive_recommended_products || []; // New

      const hasProductsToDisplay = mainRecommendedProducts.length > 0 || suggestiveRecommendedProducts.length > 0;

      const botMsg = {
        text: botResponseText,
        sender: 'bot',
        timestamp: new Date().toISOString(),
        type: hasProductsToDisplay ? 'productDisplay' : 'text',
        mainProducts: mapProductsForFrontend(mainRecommendedProducts), // New
        suggestiveProducts: mapProductsForFrontend(suggestiveRecommendedProducts), // New
        chat_id: data.chat_id, // Added chat_id to prevent chat mixing
        isShowAllProducts: data.is_show_all_products || false, // Flag to determine heading type
        isShowSelectedProducts: data.is_show_selected_products || false // Flag to determine heading type for selected products
      };

      setMessages(prev => [...prev, botMsg]);

      // Optimistically rename chat to first prompt if it's still default
      setChats(prev => prev.map(chat => {
        if (chat._id === currentChatId) {
          const isDefault = !chat.chat_name || chat.chat_name.toLowerCase() === 'new chat';
          if (isDefault && messageText) {
            const title = messageText.trim().slice(0, 60);
            // Fire and forget backend rename
            renameChat(currentChatId, title);
            return { ...chat, chat_name: title };
          }
        }
        return chat;
      }));

      setTotalCostUsd(data.conversation_cost.total_session_usd || 0);
      setTotalCostPkr(data.conversation_cost.total_session_pkr || 0);

      // Update token counts if provided
      if (data.conversation_cost.input_tokens !== undefined) {
        setTotalInputTokens(prev => prev + data.conversation_cost.input_tokens);
      }
      if (data.conversation_cost.output_tokens !== undefined) {
        setTotalOutputTokens(prev => prev + data.conversation_cost.output_tokens);
      }

    } catch (error) {
      if (error.name === 'AbortError') {
        console.log("Request was aborted by user");
        // Remove the user message since the request was cancelled
        setMessages(prev => prev.slice(0, -1));
      } else {
        console.error("❌ Failed to send message to backend:", error);
        setMessages(prev => prev.slice(0, -1));
        const errorMsg = { text: `Error: ${error.message}. Please try again.`, sender: 'bot', timestamp: new Date().toISOString() };
        setMessages(prev => [...prev, errorMsg]);
      }
    } finally {
      setLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleNewChat = async () => {
    const newChat = await createNewChat();
    if (newChat && newChat.chat && newChat.chat._id) {
      setCurrentChatId(newChat.chat._id);
      setMessages([]);
      setIsConversationStarted(false);
    }
  };

  const loadChat = async (chatId) => {
    await switchToChat(chatId);
  };

  return (
    <div className="app-container">
      <button
        className={`hamburger-menu ${sidebarOpen ? 'hidden' : ''} ${hamburgerVisible ? '' : 'fade-out'}`}
        onClick={toggleSidebar}
      >
        <FaBars />
      </button>

      <Sidebar
        sidebarOpen={sidebarOpen}
        toggleSidebar={toggleSidebar}
        onNewChat={handleNewChat}
        chats={chats}
        onChatClick={loadChat}
        onDeleteChat={deleteChat}
        onRenameChat={renameChat}
        currentChatId={currentChatId}
        totalCostUsd={totalCostUsd}
        totalCostPkr={totalCostPkr}
        totalInputTokens={totalInputTokens}
        totalOutputTokens={totalOutputTokens}
        totalImageDisplays={totalImageDisplays}
        chatLoading={chatLoading}
      />

      <MainContent
        isConversationStarted={isConversationStarted}
        messages={messages}
        onSendMessage={handleSendMessage}
        onStopMessage={handleStopMessage}
        onScroll={handleScroll}
        userId={userId}
        loading={loading}
        currentChatId={currentChatId}
        setMessages={setMessages}
      />
    </div>
  );
}

export default App;