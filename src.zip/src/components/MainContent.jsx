// MainContent.jsx
import ReactMarkdown from 'react-markdown';
import React, { useState, useRef, useEffect, useCallback } from 'react';
import ChatInput from './ChatInput';
import PromptCard from './PromptCard';
import './css/MainContent.css'; // Ensure your CSS is linked

// Generic Toast/Alert Message Component
const ToastMessage = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 3000); // Message disappears after 3 seconds
        return () => clearTimeout(timer);
    }, [onClose]);

    // Simple styling based on type
    const toastClass = `toast-message ${type}`;

    return (
        <div className={toastClass}>
            {message}
        </div>
    );
};

// SelectedProductPreview Component - Displays selected product in the preview area
const SelectedProductPreview = ({ product, onRemove }) => {
    return (
        <div className="selected-product-preview-item">
            <img src={product.src} alt={product.alt} className="selected-product-image" />
            <div className="selected-product-details">
                <h4 className="selected-product-title">{product.title}</h4>
                <p className="selected-product-price">
                    {product.on_sale && product.sale_price_pkr != null ? (
                        <>
                            <span className="original-price">PKR {product.price_pkr?.toLocaleString()}</span>
                            <span className="sale-price">PKR {product.sale_price_pkr?.toLocaleString()}</span>
                        </>
                    ) : (
                        <span>PKR {product.price_pkr?.toLocaleString() || 'N/A'}</span>
                    )}
                </p>
            </div>
            <button className="remove-selected-product" onClick={() => onRemove(product.id)}>
                ×
            </button>
        </div>
    );
};

// ProductCard Component - Handles display of individual product info in chat history
const ProductCard = ({ product, onToggleProductSelection, onViewDetail, onAddToCart, isSelected }) => {
     console.log("ProductCard props (product):", product.price_pkr); // Debugging: Check incoming product data
    return (
        <div className={`image-card product-card ${isSelected ? 'selected' : ''}`} onClick={() => onViewDetail(product)}>
            <img src={product.src} alt={product.alt} className="product-image" />
            <div className="image-details">
                <div className="title-row">
                    <h4 className="product-title">{product.title}</h4>
                    <button
                        className={`select-image-button ${isSelected ? 'selected' : ''}`}
                        onClick={(e) => {
                            e.stopPropagation(); // Prevent card's onClick (view detail) from firing
                            onToggleProductSelection(product.id); // Toggle selection
                        }}
                    >
                        {isSelected ? '✓' : '+'} {/* Change symbol based on selection */}
                    </button>
                </div>
            </div>
            <div className="price-row">
                <div className="price-info">
                    <p className="product-price-pkr">
                        {product.on_sale && product.sale_price_pkr != null ? (
                            <>
                                <span style={{ textDecoration: 'line-through', color: '#888' }}>
                                    PKR {product.price_pkr?.toLocaleString()}
                                </span>{' '}
                                <span style={{ color: '#d32f2f', fontWeight: 'bold' }}>
                                    PKR {product.sale_price_pkr?.toLocaleString()}
                                </span>
                            </>
                        ) : (
                            <span>PKR:
                                {product.price_pkr?.toLocaleString?.() || 'N/A'}
                            </span>
                        )}
                    </p>
                    <p className="product-price-usd">
                        {product.on_sale && product.sale_price_usd != null ? (
                            <>
                                <span style={{ textDecoration: 'line-through', color: '#888' }}>
                                     USD: {product.price_usd?.toLocaleString()}
                                </span>{' '}
                                <span style={{ color: '#d32f2f', fontWeight: 'bold' }}>
                                     USD: {product.sale_price_usd?.toLocaleString()}
                                </span>
                            </>
                        ) : (
                            <span>USD:
                                {product.price_usd?.toLocaleString?.() || 'N/A'}
                            </span>
                        )}
                    </p>
                </div>
            </div>
            <p className="product-description">{product.description}</p>
            <div className="product-card-actions">
                <button className="add-to-cart-button" onClick={(e) => {
                    e.stopPropagation(); // Prevent card's onClick from firing
                    onAddToCart(product.title); // Add to cart
                }}>
                    Add to Cart
                </button>
            </div>
        </div>
    );
};

// ProductDetailModal Component - Displays full details of a selected product
// ProductDetailModal Component - Displays full details of a selected product
const ProductDetailModal = ({ product, onClose, userId, onAddToCart, onShowMessage }) => {
    const [productAnalysis, setProductAnalysis] = useState("");
    const [loadingAnalysis, setLoadingAnalysis] = useState(false);
    const [errorAnalysis, setErrorAnalysis] = useState(null);

    useEffect(() => {
        // Clear analysis when modal opens for a new product
        setProductAnalysis("");
        setErrorAnalysis(null);
    }, [product]);

    const handleFetchProductAnalysis = async () => {
        if (!product || !product.id) {
            console.log("Analysis skipped: product or product.id is missing.");
            return;
        }
        setLoadingAnalysis(true);
        setErrorAnalysis(null);
        try {
            const response = await fetch('/api/product-analysis', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ product_id: product.id, user_id: userId }),
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`HTTP error: ${response.status} - ${errorData.error || response.statusText}`);
            }
            const data = await response.json();
            setProductAnalysis(data.analysis_result);
        } catch (error) {
            console.error("Error fetching product analysis:", error);
            setErrorAnalysis(`Failed to load analysis: ${error.message}`);
            setProductAnalysis("Could not retrieve product analysis at this time.");
        } finally {
            setLoadingAnalysis(false);
        }
    };

    if (!product) return null; // Don't render if no product is selected

    return (
        <div className="image-detail-modal-overlay" onClick={onClose}>
            <div className="image-detail-modal-content" onClick={(e) => e.stopPropagation()}>
                <button className="close-modal-button" onClick={onClose}>×</button>

                {/* Main content area for the modal, split into left (image) and right (details/analysis) */}
                <div className="modal-content-grid"> {/* This will be our two-column grid container */}

                    {/* Left Column: Product Image */}
                    <div className="modal-image-panel">
                        <img src={product.src} alt={product.alt} className="detail-image" />
                    </div>

                    {/* Right Column: All Product Details, AI Analysis, and Info Buttons */}
                    <div className="modal-details-panel">
                        <h4 className="product-title">{product.title}</h4>
                        <p className="product-id">SKU: {product.id}</p>
                        <p className="product-price">
                            {product.on_sale && product.sale_price_pkr != null ? (
                                <>
                                    <span style={{ textDecoration: 'line-through', color: '#888' }}>
                                        PKR: {product.price_pkr?.toLocaleString()}
                                    </span>{' '}
                                    <span style={{ color: '#d32f2f', fontWeight: 'bold' }}>
                                        PKR: {product.sale_price_pkr?.toLocaleString()}
                                    </span>
                                </>
                            ) : (
                                <span>PKR:
                                    {product.price_pkr?.toLocaleString?.() || 'N/A'}
                                </span>

                            )}
                        </p>
                        <p className="product-price">
                            {product.on_sale && product.sale_price_pkr != null ? (
                                <>
                                    <span style={{ textDecoration: 'line-through', color: '#888' }}>
                                         USD: {product.price_usd?.toLocaleString()}
                                    </span>{' '}
                                    <span style={{ color: '#d32f2f', fontWeight: 'bold' }}>
                                         USD: {product.sale_price_usd?.toLocaleString()}
                                    </span>
                                </>
                            ) : (
                                <span>
                                     USD: {product.price_usd?.toLocaleString?.() || 'N/A'}
                                </span>

                            )}
                        </p>
                        <p className="product-description">{product.description}</p>
                        <p><strong>Category:</strong> {product.category}</p>
                        <p><strong>Gender:</strong> {product.gender}</p>
                        <p><strong>Materials:</strong> {product.materials}</p>
                        <p><strong>Components:</strong> {product.components}</p>

                        {/* AI Analysis Block */}
                        <div className="product-analysis-block">
                            <h4>AI Analysis & Details</h4>
                            <p>Get insights into this product's unique features, styling tips, and more by requesting an AI analysis.</p>
                            <button
                                className="get-product-analysis-button"
                                onClick={handleFetchProductAnalysis}
                                disabled={loadingAnalysis}
                            >
                                {loadingAnalysis ? 'Analyzing...' : 'Get Product Analysis'}
                            </button>

                            {productAnalysis && (
                                <div className="analysis-output">
                                    <p>{productAnalysis}</p>
                                </div>
                            )}
                            {errorAnalysis && <p className="error-message">Error: {errorAnalysis}</p>}
                        </div>

                        {/* All four action buttons at the bottom in one row */}
                        <div className="modal-footer-buttons">
                            <button className="add-to-cart-button" onClick={() => onAddToCart(product.title)}>
                                Add to Cart
                            </button>
                            <button className="info-section-button" onClick={() => onShowMessage("Size options are listed in the product description or available upon request.")}>
                                Size Options
                            </button>
                            <button className="info-section-button" onClick={() => onShowMessage("Standard delivery takes 3-5 business days. Express options may be available at checkout.")}>
                                Delivery Info
                            </button>
                            <button className="info-section-button" onClick={() => onShowMessage("Customization options are limited. Please contact customer service for specific requests.")}>
                                Customization
                            </button>
                        </div>
                    </div>

                </div> {/* End of modal-content-grid */}
            </div>
        </div>
    );
};

// ChatHistory component definition
const ChatHistory = ({ messages, onToggleProductSelection, onViewDetail, onAddToCart, selectedProductIds, isBotTyping, scrollCarousel, suggestiveCarouselRef }) => {
    const messagesEndRef = useRef(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isBotTyping]);

    const chunkArray = (arr, size) => {
        const result = [];
        for (let i = 0; i < arr.length; i += size) {
            result.push(arr.slice(i, i + size));
        }
        return result;
    };

    // Helper function to separate products by gender
    const separateProductsByGender = (products) => {
        const maleProducts = products.filter(product => product.gender === 'Male');
        const femaleProducts = products.filter(product => product.gender === 'Female');
        const unisexProducts = products.filter(product => product.gender === 'Unisex');
        return { maleProducts, femaleProducts, unisexProducts };
    };

    // Helper function to render products with gender separation
    const renderProductsWithGenderSeparation = (products, productType) => {
        if (!products || products.length === 0) return null;

        const { maleProducts, femaleProducts, unisexProducts } = separateProductsByGender(products);
        
        return (
            <div className={`product-display-container ${productType}-products-container`}>
                {/* Female Products */}
                {femaleProducts.length > 0 && (
                    <div className="gender-section">
                        <h4 className="gender-heading">👗 Women's {productType}</h4>
                        <div className="products-grid">
                            {femaleProducts.map((product, prodIndex) => (
                                <ProductCard
                                    key={`${productType}-female-${prodIndex}`}
                                    product={product}
                                    onToggleProductSelection={onToggleProductSelection}
                                    onViewDetail={onViewDetail}
                                    onAddToCart={onAddToCart}
                                    isSelected={selectedProductIds.includes(product.id)}
                                />
                            ))}
                        </div>
                    </div>
                )}

                {/* Male Products */}
                {maleProducts.length > 0 && (
                    <div className="gender-section">
                        <h4 className="gender-heading">👔 Men's {productType}</h4>
                        <div className="products-grid">
                            {maleProducts.map((product, prodIndex) => (
                                <ProductCard
                                    key={`${productType}-male-${prodIndex}`}
                                    product={product}
                                    onToggleProductSelection={onToggleProductSelection}
                                    onViewDetail={onViewDetail}
                                    onAddToCart={onAddToCart}
                                    isSelected={selectedProductIds.includes(product.id)}
                                />
                            ))}
                        </div>
                    </div>
                )}

                {/* Unisex Products */}
                {unisexProducts.length > 0 && (
                    <div className="gender-section">
                        <h4 className="gender-heading">👥 Unisex {productType}</h4>
                        <div className="products-grid">
                            {unisexProducts.map((product, prodIndex) => (
                                <ProductCard
                                    key={`${productType}-unisex-${prodIndex}`}
                                    product={product}
                                    onToggleProductSelection={onToggleProductSelection}
                                    onViewDetail={onViewDetail}
                                    onAddToCart={onAddToCart}
                                    isSelected={selectedProductIds.includes(product.id)}
                                />
                            ))}
                        </div>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="chat-history-container">
            {messages.map((message, index) => (
                <div key={index} className={`message-bubble ${message.sender}`}>
                    {message.type === 'productDisplay' ? (
                        <>
                            <ReactMarkdown>{message.text}</ReactMarkdown>
                            
                            {/* Simple display for "Show Selected Products" */}
                            {message.isShowSelectedProducts ? (
                                <div className="product-display-container selected-products-container">
                                    {message.mainProducts && message.mainProducts.map((product, prodIndex) => (
                                        <ProductCard
                                            key={`selected-prod-${prodIndex}`}
                                            product={product}
                                            onToggleProductSelection={onToggleProductSelection}
                                            onViewDetail={onViewDetail}
                                            onAddToCart={onAddToCart}
                                            isSelected={selectedProductIds.includes(product.id)}
                                        />
                                    ))}
                                    {message.suggestiveProducts && message.suggestiveProducts.map((product, prodIndex) => (
                                        <ProductCard
                                            key={`selected-suggestive-${prodIndex}`}
                                            product={product}
                                            onToggleProductSelection={onToggleProductSelection}
                                            onViewDetail={onViewDetail}
                                            onAddToCart={onAddToCart}
                                            isSelected={selectedProductIds.includes(product.id)}
                                        />
                                    ))}
                                </div>
                            ) : message.isShowAllProducts ? (
                                <>
                                    {/* Enhanced display for "Show All Products" */}
                                    {message.mainProducts && message.mainProducts.length > 0 && (
                                        <>
                                            <div className="section-heading main-products-heading">
                                                <h3>🛍️ Main Products ({message.mainProducts.length} items)</h3>
                                            </div>
                                            {renderProductsWithGenderSeparation(message.mainProducts, 'main')}
                                        </>
                                    )}
                                    
                                    {/* Accessories with gender separation */}
                                    {message.suggestiveProducts && message.suggestiveProducts.length > 0 && (
                                        <>
                                            <div className="section-heading accessories-heading">
                                                <h3>💎 Accessories ({message.suggestiveProducts.length} items)</h3>
                                            </div>
                                            {renderProductsWithGenderSeparation(message.suggestiveProducts, 'accessory')}
                                        </>
                                    )}
                                </>
                            ) : (
                                <>
                                    {/* Regular display for normal recommendations (with 6-product limit) */}
                                    {message.mainProducts && message.mainProducts.length > 0 && (
                                        <div className="product-display-container main-products-container">
                                            {message.mainProducts.slice(0, 6).map((product, prodIndex) => (
                                                <ProductCard
                                                    key={`main-prod-${prodIndex}`}
                                                    product={product}
                                                    onToggleProductSelection={onToggleProductSelection}
                                                    onViewDetail={onViewDetail}
                                                    onAddToCart={onAddToCart}
                                                    isSelected={selectedProductIds.includes(product.id)}
                                                />
                                            ))}
                                        </div>
                                    )}
                                    
                                    {/* Conditional Heading - Accessories for "show all products", Suggestions for normal recommendations */}
                                    {message.suggestiveProducts && message.suggestiveProducts.length > 0 && (
                                        <div className={`${message.isShowAllProducts || message.isShowSelectedProducts ? 'accessories-heading' : 'suggestions-heading'} active`}>
                                            <h3>{message.isShowAllProducts || message.isShowSelectedProducts ? 'Accessories' : 'Suggestions'}</h3>
                                        </div>
                                    )}
                                    
                                    {/* Render Suggestive Products with Carousel Controls (with 6-product limit) */}
                                    {message.suggestiveProducts && message.suggestiveProducts.length > 0 && (
                                        <div className="suggestive-products-wrapper">
                                            <button className="carousel-nav-button left" onClick={() => scrollCarousel('left')}>
                                                &lt;
                                            </button>
                                            <div className="suggestive-products-container" ref={suggestiveCarouselRef}>
                                                {message.suggestiveProducts.slice(0, 6).map((product, prodIndex) => (
                                                    <ProductCard
                                                        key={`suggestive-prod-${prodIndex}`}
                                                        product={product}
                                                        onToggleProductSelection={onToggleProductSelection}
                                                        onViewDetail={onViewDetail}
                                                        onAddToCart={onAddToCart}
                                                        isSelected={selectedProductIds.includes(product.id)}
                                                    />
                                                ))}
                                            </div>
                                            <button className="carousel-nav-button right" onClick={() => scrollCarousel('right')}>
                                                &gt;
                                            </button>
                                        </div>
                                    )}
                                </>
                            )}
                        </>
                    ) : (
                        <>
                            {message.image && message.sender === 'user' && (
                                <div className="sent-image-preview">
                                    <img src={message.image.src} alt={message.image.title || 'Sent image'} className="sent-image-thumbnail" />
                                </div>
                            )}
                            <ReactMarkdown>{message.text}</ReactMarkdown>
                        </>
                    )}
                </div>
            ))}
            {/* New: Typing indicator goes here */}
            {isBotTyping && (
                <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>
    );
};

// MainContent component
function MainContent({ isConversationStarted, messages, onSendMessage, onStopMessage, onScroll, userId, loading, currentChatId, setMessages }) {
    const [inputText, setInputText] = useState("");
    const [selectedProductIds, setSelectedProductIds] = useState([]);
    const [selectedProductForDetail, setSelectedProductForDetail] = useState(null);
    const mainContentRef = useRef(null);
    const [isBotTyping, setIsBotTyping] = useState(false); // New state for typing indicator
    const suggestiveCarouselRef = useRef(null);
    const selectedProductsCarouselRef = useRef(null);

    // State for toast messages
    const [toast, setToast] = useState(null);

    const showToast = useCallback((message, type = 'info') => {
        setToast({ message, type });
    }, []);

    const closeToast = useCallback(() => {
        setToast(null);
    }, []);

    useEffect(() => {
        const handleScrollEvent = () => {
            if (mainContentRef.current) {
                onScroll(mainContentRef.current.scrollTop);
            }
        };
        const currentRef = mainContentRef.current;
        if (currentRef) {
            currentRef.addEventListener('scroll', handleScrollEvent);
        }
        return () => {
            if (currentRef) {
                currentRef.removeEventListener('scroll', handleScrollEvent);
            }
        };
    }, [onScroll]);

    // Clear selected products when switching chats
    useEffect(() => {
        setSelectedProductIds([]);
    }, [currentChatId]);

    // New function to handle carousel scrolling
const scrollCarousel = (direction) => {
    if (suggestiveCarouselRef.current) {
        const scrollAmount = suggestiveCarouselRef.current.offsetWidth / 2; // Scroll half the width of the container
        if (direction === 'left') {
            suggestiveCarouselRef.current.scrollLeft -= scrollAmount;
        } else if (direction === 'right') {
            suggestiveCarouselRef.current.scrollLeft += scrollAmount;
        }
    }
};

// Function to handle selected products carousel scrolling
const scrollSelectedProductsCarousel = (direction) => {
    if (selectedProductsCarouselRef.current) {
        const scrollAmount = 260; // Increased scroll amount for better navigation
        if (direction === 'left') {
            selectedProductsCarouselRef.current.scrollLeft -= scrollAmount;
        } else if (direction === 'right') {
            selectedProductsCarouselRef.current.scrollLeft += scrollAmount;
        }
    }
};

    
    const handlePromptClick = (promptText) => {
        setInputText(promptText);
        // Clear any selected products when a prompt is clicked to start a new line of questioning
        setSelectedProductIds([]);
    };

    // Handler for toggling product selection for chat/context
    const handleToggleProductSelection = useCallback((productId) => {
        setSelectedProductIds(prevSelected => {
            if (prevSelected.includes(productId)) {
                return prevSelected.filter(id => id !== productId); // Deselect
            } else {
                return [...prevSelected, productId]; // Select
            }
        });
    }, []);

    // Function to get selected products data from messages
    const getSelectedProductsData = useCallback(() => {
        const selectedProducts = [];
        const addedProductIds = new Set(); // Track which product IDs we've already added
        
        // Search through messages from current chat only
        messages.forEach(message => {
            // Only process messages that belong to the current chat
            if (message.chat_id === currentChatId && message.type === 'productDisplay') {
                // Check main products
                if (message.mainProducts) {
                    message.mainProducts.forEach(product => {
                        if (selectedProductIds.includes(product.id) && !addedProductIds.has(product.id)) {
                            selectedProducts.push(product);
                            addedProductIds.add(product.id);
                        }
                    });
                }
                
                // Check suggestive products
                if (message.suggestiveProducts) {
                    message.suggestiveProducts.forEach(product => {
                        if (selectedProductIds.includes(product.id) && !addedProductIds.has(product.id)) {
                            selectedProducts.push(product);
                            addedProductIds.add(product.id);
                        }
                    });
                }
            }
        });
        
        return selectedProducts;
    }, [messages, selectedProductIds, currentChatId]);

    // Function to get all selected products from chat history (for "show selected products" feature)
    const getAllSelectedProductsFromHistory = useCallback(() => {
        const allSelectedProducts = [];
        const addedProductIds = new Set(); // Track which product IDs we've already added
        
        // Search through all messages from current chat
        messages.forEach(message => {
            // Only process messages that belong to the current chat
            if (message.chat_id === currentChatId && message.type === 'productDisplay') {
                // Check main products
                if (message.mainProducts) {
                    message.mainProducts.forEach(product => {
                        if (!addedProductIds.has(product.id)) {
                            allSelectedProducts.push(product);
                            addedProductIds.add(product.id);
                        }
                    });
                }
                
                // Check suggestive products
                if (message.suggestiveProducts) {
                    message.suggestiveProducts.forEach(product => {
                        if (!addedProductIds.has(product.id)) {
                            allSelectedProducts.push(product);
                            addedProductIds.add(product.id);
                        }
                    });
                }
            }
        });
        
        return allSelectedProducts;
    }, [messages, currentChatId]);

    // Function to get all products that have been selected throughout the conversation
    const getAllSelectedProductIds = useCallback(() => {
        const selectedIds = new Set();
        
        // Get all selected products from the current chat
        const allProducts = getAllSelectedProductsFromHistory();
        allProducts.forEach(product => {
            selectedIds.add(product.id);
        });
        
        return Array.from(selectedIds);
    }, [getAllSelectedProductsFromHistory]);

    // Handler for clearing all selected products
    const handleClearSelectedProducts = useCallback(() => {
        setSelectedProductIds([]);
    }, []);

    const handleViewDetail = async (product) => {
        if (!product || !product.id) {
            console.error("No product or product ID provided for detail view.");
            return;
        }
        try {
            const response = await fetch(`/api/product-details/${product.id}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`HTTP error: ${response.status} - ${errorData.error || response.statusText}`);
            }
            const fullProductDetails = await response.json();
            console.log("Materials from fetched data:", fullProductDetails.materials);
            console.log("Components from fetched data:", fullProductDetails.components);
            setSelectedProductForDetail({
                id: fullProductDetails.id,
                src: fullProductDetails.image_urls[0],
                alt: fullProductDetails.name,
                title: fullProductDetails.name,
                price_pkr: fullProductDetails.price_pkr,
                price_usd: fullProductDetails.price_usd,
                sale_price_pkr: fullProductDetails.sale_price_pkr,
                sale_price_usd: fullProductDetails.sale_price_usd,
                on_sale: fullProductDetails.on_sale,
                description: fullProductDetails.description,
                category: fullProductDetails.category,
                gender: fullProductDetails.gender,
                materials: fullProductDetails.materials,
                components: fullProductDetails.components,
                details: fullProductDetails.details,
                sizes_available: fullProductDetails.sizes_available,
                colors_available: fullProductDetails.colors_available,
                in_stock: fullProductDetails.in_stock,
            });
        } catch (error) {
            console.error("Error fetching product details:", error);
            showToast(`Failed to load product details: ${error.message}`, 'error');
        }
    };

    const handleCloseProductDetail = useCallback(() => {
        setSelectedProductForDetail(null);
    }, []);

    const handleAddToCartGeneral = useCallback((productTitle) => {
        showToast(`"${productTitle}" added to cart!`, 'success');
    }, [showToast]);

    const handleSendMessage = async (messagePayload) => {
        let textToSend = messagePayload.text;
        let imageBase64ToSend = messagePayload.image;

        // Check if user is asking to show selected products
        const isAskingForSelectedProducts = textToSend.toLowerCase().includes('show selected') || 
                                          textToSend.toLowerCase().includes('display selected') ||
                                          textToSend.toLowerCase().includes('show my') ||
                                          textToSend.toLowerCase().includes('display my') ||
                                          textToSend.toLowerCase().includes('products i selected') ||
                                          textToSend.toLowerCase().includes('products i chose');

        let product_ids_to_send = selectedProductIds;

        // If asking for selected products, include all selected product IDs
        if (isAskingForSelectedProducts) {
            // Get all selected products from the current chat
            product_ids_to_send = getAllSelectedProductIds();
            
            // Add context about selected products
            if (product_ids_to_send.length > 0) {
                const productIdsString = product_ids_to_send.join(', ');
                textToSend = `Show selected products (IDs: ${productIdsString}): ${textToSend}`;
            }
        } else if (selectedProductIds.length > 0) {
            // Regular context for selected products
            const productTitles = messages
                .filter(msg => msg.chat_id === currentChatId) // Only messages from current chat
                .flatMap(msg => [...(msg.mainProducts || []), ...(msg.suggestiveProducts || [])]) // Combine main and suggestive for search
                .filter(product => selectedProductIds.includes(product.id))
                .map(product => product.title);

            const productIdsString = selectedProductIds.join(', ');
            let selectedProductsContext = "";
            if (productTitles.length === selectedProductIds.length) {
                selectedProductsContext = `Regarding: ${productTitles.join(', ')} (IDs: ${productIdsString}): `;
            } else {
                selectedProductsContext = `Regarding selected products (IDs: ${productIdsString}): `;
            }

            textToSend = selectedProductsContext + textToSend;
        }

        setIsBotTyping(true);

        try {
            await onSendMessage({
                text: textToSend,
                image: imageBase64ToSend,
                product_ids: product_ids_to_send
            });
        } catch (error) {
            console.error("Error sending message or getting bot response:", error);
        } finally {
            setIsBotTyping(false);
        }

        handleClearSelectedProducts();
        setInputText("");
    };



    const chatInputPlaceholder = selectedProductIds.length > 0
        ? `Ask Kayseria-AI more about these ${selectedProductIds.length} items`
        : "Whatever you need, just ask Style Sense!";

    return (
        <div className={`main-content c1 ${isConversationStarted ? 'conversation-active c2' : 'initial-layout'}`} ref={mainContentRef}>
            <div className="content-area">
                {!isConversationStarted ? (
                    <>
                        <section className="welcome-section">
                            <h1>Welcome to Style Sense</h1>
                            <h2>Ask me anything—I'm here to help!</h2>
                        </section>
                        <div className="chat-input-wrapper initial-chat-input-wrapper">
                            <ChatInput
                                onSendMessage={handleSendMessage}
                                onStopMessage={onStopMessage}
                                inputText={inputText}
                                setInputText={setInputText}
                                placeholderText={chatInputPlaceholder}
                                onClearSelectedProducts={handleClearSelectedProducts}
                                selectedProductIds={selectedProductIds}
                                loading={loading}
                            />
                        </div>
                        <section className="explore-prompts">
                            <h3>Explore by ready prompt</h3>
                            <div className="prompt-cards-container">
                                <PromptCard
                                    icon="👗"
                                    title="Stitched Collection"
                                    description="Explore our ready-to-wear stitched designs, perfect for effortless elegance."
                                    onClick={() => handlePromptClick("Tell me about your stitched collection.")}
                                />
                                <PromptCard
                                    icon="🧵"
                                    title="Unstitched Fabrics"
                                    description="Discover our premium unstitched fabrics, waiting for your custom touch."
                                    onClick={() => handlePromptClick("Show me your unstitched fabric designs.")}
                                />
                                <PromptCard
                                    icon="💍"
                                    title="Bridal & Formal Wear"
                                    description="Browse our exquisite collection for special occasions and celebrations."
                                    onClick={() => handlePromptClick("What bridal and formal wear options do you have?")}
                                />
                                <PromptCard
                                    icon="🛍️"
                                    title="Budget Limit"
                                    description="Want dresses in a range? or under a specific price? We're here to assist."
                                    onClick={() => handlePromptClick("Show me dresses under 10000.")}
                                />
                            </div>
                        </section>
                    </>
                ) : (
                    <>
                        <ChatHistory
                            messages={messages}
                            onToggleProductSelection={handleToggleProductSelection}
                            onViewDetail={handleViewDetail}
                            onAddToCart={handleAddToCartGeneral}
                            selectedProductIds={selectedProductIds}
                            isBotTyping={isBotTyping}
                            // Pass the new props to ChatHistory
                            scrollCarousel={scrollCarousel} 
                            suggestiveCarouselRef={suggestiveCarouselRef}
                        />
                        <div className="chat-fade-overlay c3"></div>
                        <div className="chat-input-wrapper conversation-chat-input-wrapper">
                            {/* New: Multiple products selection preview */}
                            {selectedProductIds.length > 0 && (
                                <div className="selected-products-preview">
                                    <button 
                                        className="selected-products-carousel-nav left" 
                                        onClick={() => scrollSelectedProductsCarousel('left')}
                                    >
                                        &lt;
                                    </button>
                                    <div className="selected-products-list" ref={selectedProductsCarouselRef}>
                                        {getSelectedProductsData().map((product) => (
                                            <SelectedProductPreview
                                                key={product.id}
                                                product={product}
                                                onRemove={handleToggleProductSelection}
                                            />
                                        ))}
                                    </div>
                                    <button 
                                        className="selected-products-carousel-nav right" 
                                        onClick={() => scrollSelectedProductsCarousel('right')}
                                    >
                                        &gt;
                                    </button>

                                </div>
                            )}
                            <ChatInput
                                onSendMessage={handleSendMessage}
                                onStopMessage={onStopMessage}
                                inputText={inputText}
                                setInputText={setInputText}
                                placeholderText={chatInputPlaceholder}
                                onClearSelectedProducts={handleClearSelectedProducts}
                                selectedProductIds={selectedProductIds}
                                loading={loading}
                            />
                        </div>
                    </>
                )}
            </div>
            {/* Product Detail Modal */}
            <ProductDetailModal
                product={selectedProductForDetail}
                onClose={handleCloseProductDetail}
                userId={userId}
                onAddToCart={handleAddToCartGeneral}
                onShowMessage={showToast}
            />

            {/* Toast Message Display */}
            {toast && (
                <ToastMessage message={toast.message} type={toast.type} onClose={closeToast} />
            )}
        </div>
        
    );

    
}

export default MainContent;