import React, { useRef, useState, useEffect } from "react";
import "./css/ChatInput.css";

// Add `loading` as a new prop
function ChatInput({ onSendMessage, inputText, setInputText, placeholderText, selectedProductIds, onClearSelectedProducts, loading, onStopMessage }) {
  const fileInputRef = useRef(null);
  const [isRecording, setIsRecording] = useState(false);
  const mediaStreamRef = useRef(null);
  const recordingTimeoutRef = useRef(null);

  const handleUploadImageClick = () => {
    fileInputRef.current.click();
  };

  const handleStop = () => {
    if (onStopMessage) {
      onStopMessage();
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result.split(',')[1];
        console.log("Selected image converted to base64.");
        onSendMessage({ text: inputText, image: base64String, product_ids: selectedProductIds });
        setInputText("");
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        onClearSelectedProducts();
      };
      reader.onerror = (error) => {
        console.error("Error reading file:", error);
        showCustomMessageBox("Error reading image file.");
      };
      reader.readAsDataURL(file);
    } else {
      console.log("No image selected or cancelled.");
    }
  };

  const startRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.log("Your browser does not support media devices (microphone).");
        showCustomMessageBox("Microphone not supported on this browser.");
        return;
      }

      const permissionStatus = await navigator.permissions.query({ name: 'microphone' });
      if (permissionStatus.state === 'denied') {
        console.log("Microphone access previously denied. Please enable it in your browser settings.");
        showCustomMessageBox("Microphone access denied. Please enable it in your browser settings.");
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      console.log("Microphone access granted. Recording started:", stream);
      setIsRecording(true);

      recordingTimeoutRef.current = setTimeout(() => {
        if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach(track => track.stop());
          console.log("Microphone stream stopped automatically after 60 seconds.");
          setIsRecording(false);
          mediaStreamRef.current = null;
          recordingTimeoutRef.current = null;
        }
      }, 60 * 1000);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        console.log("Microphone access denied. Please allow permissions in your browser settings.");
        showCustomMessageBox("Microphone access denied. Please allow permissions in your browser settings.");
      } else {
        console.log("An error occurred accessing microphone: " + err.message);
        showCustomMessageBox("An error occurred accessing microphone: " + err.message);
      }
      setIsRecording(false);
      mediaStreamRef.current = null;
      if (recordingTimeoutRef.current) {
        clearTimeout(recordingTimeoutRef.current);
        recordingTimeoutRef.current = null;
      }
    }
  };

  const stopRecording = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      console.log("Microphone stream stopped manually.");
      mediaStreamRef.current = null;
    }
    setIsRecording(false);
    if (recordingTimeoutRef.current) {
      clearTimeout(recordingTimeoutRef.current);
      recordingTimeoutRef.current = null;
    }
  };

  const handleVoiceMessageClick = () => {
    if (!isRecording) {
      startRecording();
    } else {
      stopRecording();
    }
  };

  useEffect(() => {
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (recordingTimeoutRef.current) {
        clearTimeout(recordingTimeoutRef.current);
      }
    };
  }, []);

  const handleSend = () => {
    if (onSendMessage) {
      onSendMessage({ text: inputText, image: null, product_ids: selectedProductIds });
      setInputText("");
      onClearSelectedProducts();
    }
  };

  const handleButtonClick = () => {
    if (loading) {
      handleStop();
    } else {
      handleSend();
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleButtonClick();
    }
  };

  const showCustomMessageBox = (message) => {
    console.warn("Custom Message Box:", message);
  };

  return (
    <div className="chat-input-container">
      <textarea
        id="chat-message-textarea"
        className="chat-textarea"
        placeholder={placeholderText}
        rows="3"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        onKeyDown={handleKeyDown}
      ></textarea>
      <div className="chat-actions">
        <div className="action-buttons-left">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            style={{ display: 'none' }}
            accept="image/*"
          />
          <button className="action-button" onClick={handleUploadImageClick}>
            <strong className="strong">+</strong> Upload Image
          </button>
        </div>
        <div className="action-buttons-right">
          <button className="action-button" onClick={handleVoiceMessageClick}>
            {isRecording ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-stop-fill" viewBox="0 0 16 16">
                <path d="M5 3.5h6A1.5 1.5 0 0 1 12.5 5v6a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 11V5A1.5 1.5 0 0 1 5 3.5"/>
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-mic-fill" viewBox="0 0 16 16">
                <path d="M5 3a3 3 0 0 1 6 0v5a3 3 0 0 1-6 0z"/>
                <path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3.5 8V7a.5.5 0 0 1 .5-.5"/>
              </svg>
            )}
          </button>
          {/* Conditional rendering for the Send/Stop button */}
          <button className="send-button" onClick={handleButtonClick}>
            {loading ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-stop-fill"
                viewBox="0 0 16 16"
              >
                <path d="M5 3.5h6A1.5 1.5 0 0 1 12.5 5v6a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 11V5A1.5 1.5 0 0 1 5 3.5"/>
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-send-fill"
                viewBox="0 0 16 16"
              >
                <path d="M15.964.686a.5.5 0 0 0-.65-.65L.767 5.855H.766l-.452.18a.5.5 0 0 0-.082.887l.41.26.001.002 4.995 3.178 3.178 4.995.002.002.26.41a.5.5 0 0 0 .886-.083zm-1.833 1.89L6.637 10.07l-.215-.338a.5.5 0 0 0-.154-.154l-.338-.215 7.494-7.494 1.178-.471z" />
              </svg>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ChatInput;