import React, { useState } from 'react';
import './css/Sidebar.css';
import { FaGlobe, FaComments, FaHistory, FaUserCircle, FaStore, FaPlus, FaTimes, FaDollarSign, FaRupeeSign, FaHashtag, FaImage, FaCaretDown } from 'react-icons/fa'; // Added FaCaretDown for dropdown indicator

function Sidebar({
  sidebarOpen,
  toggleSidebar,
  onNewChat,
  chats,
  onChatClick,
  onDeleteChat,
  onRenameChat,
  currentChatId,
  // New props for cost information
  totalCostUsd,
  totalCostPkr,
  totalInputTokens,
  totalOutputTokens,
  totalImageDisplays,
  chatLoading,
}) {
  const [showChatsDropdown, setShowChatsDropdown] = useState(false);
  const [showBrandsDropdown, setShowBrandsDropdown] = useState(false);
  const [editingChatId, setEditingChatId] = useState(null);
  const [editingChatName, setEditingChatName] = useState('');

  // Define your brand links here
  const brandLinks = [
    { name: 'Kayseria', url: 'https://www.kayseria.com/' },
    { name: 'Limelight', url: 'https://www.limelight.pk/' },
    { name: 'Nishat Linen', url: 'https://nishatlinen.com/' },
    { name: 'Sapphire', url: 'https://pk.sapphireonline.pk/' },
    { name: 'Generation', url: 'https://www.generation.com.pk/' }, // Example additional brand
  ];

  return (
    <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
      <div className="sidebar-header">
        <span className="logo-icon"><FaStore /></span>
        <span className="logo-text">StyleSense</span>
        <button className="sidebar-close-btn" onClick={toggleSidebar}><FaTimes /></button>
      </div>

      <div className="sidebar-scrollable-content">
        <nav className="sidebar-nav">
          <ul>
            <li><button className="nav-item new-chat-btn" onClick={onNewChat}><FaPlus className="nav-icon" /><span>New Chat</span></button></li>
            
            {/* Brands Dropdown Section */}
            <li className="brands-dropdown-container"
                onMouseEnter={() => setShowBrandsDropdown(true)}
                onMouseLeave={() => setShowBrandsDropdown(false)}
            >
              <div className={`nav-item brands-dropdown-toggle ${showBrandsDropdown ? 'active-dropdown-toggle' : ''}`}>
                <FaGlobe className="nav-icon" />
                <span>Visit Brands</span>
                <FaCaretDown className="dropdown-caret" /> {/* Caret icon */}
              </div>
              {showBrandsDropdown && (
                <div className="brands-dropdown-menu">
                  <ul>
                    {brandLinks.map((brand, index) => (
                      <li key={index}>
                        <a href={brand.url} target="_blank" rel="noopener noreferrer" className="brands-dropdown-item"
                           onClick={() => setShowBrandsDropdown(false)} // Close dropdown on click
                        >
                          {brand.name}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </li>
            
            <li><a href="/" className="nav-item active"><FaComments className="nav-icon" /><span>AI Assistant</span></a></li>
            <li className="chats-container" onMouseEnter={() => setShowChatsDropdown(true)} onMouseLeave={() => setShowChatsDropdown(false)}>
              <div className={`nav-item chats-toggle ${showChatsDropdown ? 'active-dropdown-toggle' : ''}`}>
                <FaHistory className="nav-icon" />
                <span>My Chats</span>
                {chatLoading && <span className="loading-indicator">...</span>}
              </div>
              {showChatsDropdown && (
                <div className="chats-dropdown">
                  {chats.length > 0 ? (
                    <ul>
                      {chats.map((chat) => (
                        <li key={chat._id} className="chat-item">
                          {editingChatId === chat._id ? (
                            <div className="chat-edit-container">
                              <input
                                type="text"
                                value={editingChatName}
                                onChange={(e) => setEditingChatName(e.target.value)}
                                onKeyPress={(e) => {
                                  if (e.key === 'Enter') {
                                    onRenameChat(chat._id, editingChatName);
                                    setEditingChatId(null);
                                    setEditingChatName('');
                                  }
                                }}
                                onBlur={() => {
                                  setEditingChatId(null);
                                  setEditingChatName('');
                                }}
                                autoFocus
                                className="chat-edit-input"
                              />
                            </div>
                          ) : (
                            <div className="chat-item-content">
                              <button 
                                className={`chat-item-button ${chat._id === currentChatId ? 'selected' : ''}`} 
                                onClick={() => { 
                                  onChatClick(chat._id); 
                                  setShowChatsDropdown(false); 
                                }}
                              >
                                <span className="chat-item-title">{chat.chat_name}</span>
                                {chat.last_updated && (
                                  <span className="chat-item-date">{new Date(chat.last_updated).toLocaleDateString()}</span>
                                )}
                              </button>
                              <div className="chat-item-actions">
                                <button 
                                  className="chat-action-btn edit-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingChatId(chat._id);
                                    setEditingChatName(chat.chat_name);
                                  }}
                                  title="Rename chat"
                                >
                                  ✏️
                                </button>
                                <button 
                                  className="chat-action-btn delete-btn"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (window.confirm('Are you sure you want to delete this chat?')) {
                                      onDeleteChat(chat._id);
                                    }
                                  }}
                                  title="Delete chat"
                                >
                                  🗑️
                                </button>
                              </div>
                            </div>
                          )}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="no-chats-message">No chats yet. Start a new conversation!</p>
                  )}
                </div>
              )}
            </li>
          </ul>
        </nav>

        {/* New section for Cost Information */}
        <div className="cost-info-section">
          <h4>Usage Metrics</h4>
          <p><FaDollarSign className="nav-icon" /> Total USD: {totalCostUsd.toFixed(4)}</p>
          <p><FaRupeeSign className="nav-icon" /> Total PKR: {totalCostPkr.toFixed(2)}</p>
          <p><FaHashtag className="nav-icon" /> Input Tokens: {totalInputTokens}</p>
          <p><FaHashtag className="nav-icon" /> Output Tokens: {totalOutputTokens}</p>
          <p><FaImage className="nav-icon" /> Image Displays: {totalImageDisplays}</p>
        </div>

      </div>

      <div className="sidebar-footer">
        <div className="user-profile">
          <FaUserCircle className="user-avatar-icon" />
          <div className="user-info">
            <p className="user-name">Guest User</p>
            <p className="user-email">guestuser@example.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;