// PromptCard.jsx
import React from 'react';
import './css/MainContent.css';

// PromptCard now accepts an onClick prop
function PromptCard({ icon, title, description, onClick }) {
  return (
    // Add onClick handler to the main div
    <div className="prompt-card" onClick={onClick}>
      <div className="card-icon">{icon}</div>
      <h4>{title}</h4>
      <p>{description}</p>
    </div>
  );
}

export default PromptCard;